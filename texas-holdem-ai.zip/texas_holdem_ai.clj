(ns texas-holdem-ai.settings
  (:gen-class))

;;This file is for code that creates or updates the map for game settings below.

;;Settings time_bank i -> Maximum time in milliseconds that your bot has in its time bank
;;Settings time_per_move i -> Time in milliseconds that is added to your bot's time bank each move
;;Settings hands_per_level i -> Number of hands that is played within each blind level
;;Settings starting_stack i ->Amount of chips that each bot starts the game with
;;Settings your_bot b -> The name of your bot during this match

;;Explictly set your bot and opponets names here since opp bot name is never explictly set
(defn parseBotNames
  [botName settingsInfo]
  (if (= botName "player1")
    (conj settingsInfo {:your_bot "player1" :opp_bot "player2"})
    (conj settingsInfo {:your_bot "player2" :opp_bot "player1"})))

;;Handles actual editing of the settings dictionary directly
(defn parseSetting
  [setting value settingsInfo]
  (cond
    (= setting "your_bot") (parseBotNames value settingsInfo)
    true (if (contains? settingsInfo (keyword setting))
          (assoc settingsInfo (keyword setting) value) ;;Replace the value and build a new object
          (conj settingsInfo [(keyword setting) value])))) ;;build a new object with an added kvp


;;Entry point for updating or adding settings through the state object
(defn parseStateSettings
  [setting value currentState]
  (assoc currentState :settingsInfo (parseSetting setting value (get currentState :settingsInfo))))

;;Shortcut method to get a specfic setting
(defn getSetting
  [currentState key]
  (get-in currentState [:settingsInfo (keyword key)]))

;;Shortcut methods to get bot names
(defn your_bot
  [currentState]
  (get-in currentState [:settingsInfo :your_bot]))

(defn opp_bot
  [currentState]
  (get-in currentState [:settingsInfo :your_bot]))
(ns texas-holdem-ai.util
  (:gen-class))

  ;;Log output to stderr, log file outputted from game engine
  (defn log
    [text]
    (.println *err* (pr-str text))
    text)
(ns texas-holdem-ai.state
  (:gen-class))

;;Util Functions
(defn getHand
  [currentState]
  (get currentState :hand))

;; Defines for the possible game states to avoid magic numbers
(def STATE-NONE 0)
(def STATE-PREFLOP 1)
(def STATE-FLOP 2)
(def STATE-TURN 3)
(def STATE-RIVER 4)

;;Compute state by board state
(defn computeStateByBoard
  [board]
  (condp = (count board)
    0 STATE-PREFLOP
    3 STATE-FLOP
    4 STATE-TURN
    5 STATE-RIVER))

;;Shortcut to get the current hand state
(defn getHandState
  [currentState]
  (get currentState :gameState))

;;Shortcut to set a updated hand state
(defn setHandState
  [currentState newHandState]
  (assoc currentState :gameState newHandState))
(ns texas-holdem-ai.handParse
  (:gen-class))

;;This file focuses on turning the text representation of the hand into a structure useful to the ai

(defn removeBrackets
  [handString]
  (apply str (remove #((set "[]") %) handString)))

(defn buildCardList
  [handString]
  (clojure.string/split handString #","))

(defn translateCardToNum
  [card]
  (case card
    \2 2
    \3 3
    \4 4
    \5 5
    \6 6
    \7 7
    \8 8
    \9 9
    \T 10
    \J 11
    \Q 12
    \K 13
    \A 14))

(defn parseCardPair
  [card]
  {:CardVal (translateCardToNum (get card 0)) :Suite (get card 1)})

(defn handParser
  [handString]
  (into [] (map parseCardPair (buildCardList (removeBrackets handString)))))
(ns texas-holdem-ai.handState
  (:use [texas-holdem-ai settings handParse state])
  (:gen-class))

;;This process and stores all mid hand moves and changes to player state

;;b stack i -> The amount of chips that the given bot has left in his stack
;;b post i -> The given bot pays a blind of the given size
;;b hand [c,c] -> The hand that the given bot has
;;b fold 0 -> The given bot folds, always followed by the number zero
;;b check 0 -> The given bot checks, always followed by the number zero
;;b call i -> The given bot calls with the given amount of chips
;;b raise i -> The given bot raises with the given amount of chips
;;b wins i -> The given bot wins an amount of chips at the end of a hand

(defn your_botMoves
  [action value currentState]
  (case action
    "hand" (conj currentState {:hand (handParser value) :gameState STATE-PREFLOP})
    "stack" (conj currentState {:stack (Integer. value)})
    "post" (if (= value (get-in currentState [:matchInfo :big_blind]))
            (conj currentState {:isBB true})
            (conj currentState {:isBB false}))
    "wins" (conj currentState {:board [] :hand []})
    currentState))

(defn opp_botMoves
  [action value currentState]
  (case action
    "wins" (conj currentState {:board [] :hand []})
    (conj currentState {:last_opp_move action :last_opp_val value})))

(defn parseStateHand
  [botName action value currentState]
  (condp = botName
    (your_bot currentState) (your_botMoves action value currentState)
    (opp_bot currentState) (opp_botMoves action value currentState)))


(defn getMyStack
  [currentState]
  (get currentState :stack))

(defn getMyHand
  [currentState]
  (get currentState :hand))
(ns texas-holdem-ai.match
  (:use [texas-holdem-ai handParse state])
  (:gen-class))

;;The match is data that persists through multiple hands but not permanently through execution

;;Match round i -> The number of the currently played hand, counting starts at 1
;;Match small_blind i -> The current size of the small blind
;;Match big_blind i -> The current size of the big blind
;;Match on_button b -> The name of the bot that currently has the dealer button (gets the small blind)
;;Match table [c,c,c,...] -> The cards that are currently on the table
;;Match max_win_pot i -> Total amount of chips currently in the pot (plus sidepot)
;;Match amount_to_call i -> The amount of chips your bot has to put in to call

;;Handles actual editing of the settings dictionary directly
(defn parseMatch
  [setting value matchMap]
  (if (contains? matchMap (keyword setting))
    (assoc matchMap (keyword setting) value) ;;Replace the value and build a new object
    (conj matchMap [(keyword setting) value]))) ;;build a new object with an added kvp


;;Entry point for updating or adding settings through the state object
(defn parseStateMatch
  [setting value currentState]
  (case setting
    "table" (let [cards (handParser value)] (conj currentState {:board cards :gameState (computeStateByBoard cards)}))
    (assoc currentState :matchInfo (parseMatch setting value (get currentState :matchInfo)))))

;;Shortcut method to get a specfic setting
(defn getMatch
  [currentState key]
  (get-in currentState [:matchInfo (keyword key)]))

;;Shortcut to update an existing value
(defn setMatch
  [key value currentState]
  (parseStateMatch key value currentState))

;;Shortcut to get the common cards, TODO: maybe this should be stored this way instead of converted
(defn getBoard
  [currentState]
  (get currentState :board))

(defn getAmountToCall
  [currentState]
  (Integer. (get-in currentState [:matchInfo :amount_to_call])))

(defn getBigBlind
  [currentState]
  (Integer. (get-in currentState [:matchInfo :big_blind])))
(ns texas-holdem-ai.card
  (:use [texas-holdem-ai util])
  (:gen-class))

(defn faceCard
  [card]
  (if (or (= (card :CardVal) 11) (= (card :CardVal) 12) (= (card :CardVal) 13) (= (card :CardVal) 14) (= (card :CardVal) 10)) true false))

;;Straight computation stuff
;;Must come in to this function sorted!
(defn connectedCards
  [cards holes]
  (cond
    (empty? cards) holes
    (= (second cards) nil) (connectedCards [] holes)
    true (connectedCards (rest cards) (+ holes (- ((second cards) :CardVal) ((first cards) :CardVal))))))

(defn connectedCards2
  [cards spot]
  (cond
    (empty? cards) true
    (= spot 4) true
    true (if (= (+ ((first cards) :CardVal) 1) ((second cards) :CardVal))
          (connectedCards2 (rest cards) (+ 1 spot))
          false)))

;;Board Pairs+
(defn combineLikeCards
  [pocket board]
  (group-by :CardVal (concat pocket board)))

(defn largestSet
  [dictkeys cards highestValue setSize]
  (cond
    (empty? dictkeys) highestValue
    true (let [coll (cards (first dictkeys))]
          (if (= (count coll) setSize)
            (if (< highestValue (first dictkeys))
              (largestSet (rest dictkeys) cards (first dictkeys) setSize)
              (largestSet (rest dictkeys) cards highestValue setSize))
            (largestSet (rest dictkeys) cards highestValue setSize)))))

(defn findCollections
  [size pocket board]
  (let [allCards (combineLikeCards pocket board)]
    (largestSet (keys allCards) allCards 0 size)))

;;Board Flush
(defn largestSuite
  [dictKeys cards biggestSet]
  (cond
    (empty? dictKeys) biggestSet
    true (let [collSize (count (cards (first dictKeys)))]
          (if (> collSize biggestSet)
            (largestSuite (rest dictKeys) cards collSize)
            (largestSuite (rest dictKeys) cards biggestSet)))))

(defn suiteDetector
  [pocket board]
  (let [cards (group-by :Suite (concat pocket board))]
    (largestSuite (keys cards) cards 0)))
(ns texas-holdem-ai.bets
  (:use [texas-holdem-ai state match settings handState util])
  (:gen-class))

(defn betPreflop
  [handType handVal currentState]
  (let [bigBlind (getBigBlind currentState) stack (getMyStack currentState)]
    (case handType
      "pair" (case (handVal 1)
              14 stack
              13 (* 5 bigBlind)
              12 (* 4 bigBlind)
              11 (* 2 bigBlind)
              10 (* 2 bigBlind)
              (* 1 bigBlind))
      "flush" (* 3 bigBlind)
      "straight" 0
      "straightflush" (* 2 bigBlind)
      "highHand" (case (handVal 1)
                  14 (* 5 bigBlind)
                  13 (* 4 bigBlind)
                  (* 2 bigBlind))
      0)))

(defn betFlop
  [handType handVal currentState]
  (let [bigBlind (getBigBlind currentState) stack (getMyStack currentState)]
    (case handType
      "pair" (case (handVal 1)
              14 (* 3 bigBlind)
              13 (* 3 bigBlind)
              12 (* 2 bigBlind)
              11 (* 2 bigBlind)
              10 (* 2 bigBlind)
              (* 1 bigBlind))
      "4flush" (* 0.2 stack)
      "flush" (* 0.3 stack)
      "straight" (* 0.5 stack)
      "straightflush" stack
      "highHand" 0
      "trips" (* 0.15 stack)
      "quads" stack
      "fullhouse" (* 0.5 stack)
      "twopair" (* 4 bigBlind)
      0)))


(defn betTurn
  [handType handVal currentState]
  (let [bigBlind (getBigBlind currentState) stack (getMyStack currentState)]
    (case handType
      "pair" (case (handVal 1)
              14 (* 3 bigBlind)
              13 (* 2 bigBlind)
              12 (* 2 bigBlind)
              11 (* 1 bigBlind)
              10 (* 1 bigBlind)
              (* 1 bigBlind))
      "4flush" (* 0.15 stack)
      "flush" (* 0.3 stack)
      "straight" (* 0.5 stack)
      "straightflush" stack
      "highHand" 0
      "trips" (* 10 bigBlind)
      "quads" stack
      "fullhouse" (* 0.5 stack)
      "twopair" (* 4 bigBlind)
      0)))


(defn betRiver
  [handType handVal currentState]
  (let [bigBlind (getBigBlind currentState) stack (getMyStack currentState)]
    (case handType
      "pair" (case (handVal 1)
              14 (* 3 bigBlind)
              13 (* 2 bigBlind)
              12 (* 2 bigBlind)
              11 (* 1 bigBlind)
              10 (* 1 bigBlind)
              (* 1 bigBlind))
      "flush" (* 0.3 stack)
      "straight" (* 0.5 stack)
      "straightflush" stack
      "highHand" 0
      "trips" (* 8 bigBlind)
      "quads" stack
      "fullhouse" (* 0.5 stack)
      "twopair" (* 3 bigBlind)
      0)))
(ns texas-holdem-ai.commonHands
  (:use [texas-holdem-ai state card])
  (:gen-class))

(defn flush?
  [pocket board]
  (let [flushData (suiteDetector pocket board)]
    (if (= flushData 5)
      [true 5]
      [false flushData])))

(defn fullhouse?
  [pocket board]
  (let [tripsVal (findCollections 3 pocket board) pairVal (findCollections 2 pocket board)]
    (if (and (< 0 tripsVal) (< 0 pairVal))
      [true tripsVal pairVal]
      [false nil nil])))

(defn twopair?
  [pocket board]
  (let [pair1Val (findCollections 2 pocket board) pair2Val (findCollections 2 (remove #(= (% :CardVal) pair1Val) pocket) (remove #(= (% :CardVal) pair1Val) board))]
    (if (and (< 0 pair1Val) (< 0 pair2Val))
      [true pair1Val pair2Val]
      [false nil nil])))

(defn straight-options
  [pocket board]
  (let [sboard (sort-by :CardVal board)]
    (condp = (count board)
      0 [(connectedCards (sort-by :CardVal pocket) 0)]
      3 [(connectedCards (sort-by :CardVal (concat pocket board)) 0)]
      4 [(connectedCards (sort-by :CardVal (concat pocket [(board 0) (board 1) (board 2)])) 0) (connectedCards (sort-by :CardVal (concat pocket [(board 1) (board 2) (board 3)])) 0)]
      5 [(connectedCards (sort-by :CardVal (concat pocket [(board 0) (board 1) (board 2)])) 0) (connectedCards (sort-by :CardVal (concat pocket [(board 1) (board 2) (board 3)])) 0)
          (connectedCards (sort-by :CardVal (concat pocket [(board 2) (board 3) (board 4)])) 0)])))

(defn oldStraight?
  [pocket board]
  (let [cardCount (+ (count pocket) (count board))]
    (if (< (apply min (straight-options pocket board)) 5)
      [true]
      [false])))

(defn straight?
  [pocket board]
  (condp = (count board)
    3 [(connectedCards2 (sort-by :CardVal (concat pocket board)) 0)]
    4 [(connectedCards2 (rest (sort-by :CardVal (concat pocket board))) 0) (connectedCards2 (sort-by :CardVal (concat pocket board)) 0)]
    5 [(connectedCards2 (rest (sort-by :CardVal (concat pocket board))) 0) (connectedCards2 (sort-by :CardVal (concat pocket board)) 0) (connectedCards2 (rest (rest (sort-by :CardVal (concat pocket board)))) 0)]
    ))

(defn trips?
  [pocket board]
  (let [highVal (findCollections 3 pocket board)]
    (if (< 0 highVal)
      [true highVal]
      [false nil])))

(defn quads?
  [pocket board]
  (let [highVal (findCollections 4 pocket board)]
      (if (< 0 highVal)
        [true highVal]
        [false nil])))

(defn pair?
  [pocket board]
  (let [highVal (findCollections 2 pocket board)]
    (if (< 0 highVal)
      [true highVal]
      [false nil])))

(defn straightflush?
  [pocket board]
  (let [straightData (straight? pocket board) flushData (flush? pocket board)]
    (if (and (= (straightData 0) true) (= (flushData 0) true))
      [true]
      [false])))
(ns texas-holdem-ai.pocketHands
  (:use [texas-holdem-ai state card])
  (:gen-class))


(defn pocketPairs?
  [hand]
  (if (= ((hand 0) :CardVal) ((hand 1) :CardVal)) [true ((hand 0) :CardVal)] [false nil]))

(defn pocketFlush?
  [hand]
  (if (= ((hand 0) :Suite) ((hand 1) :Suite))
    [true ((hand 1) :Suite)]
    [false nil]))

(defn pocketStraight?
  [hand]
  (if (or (= ((hand 0) :CardVal) (+ ((hand 1) :CardVal) 1)) (= ((hand 0) :CardVal) (- ((hand 1) :CardVal) 1)))
    [true (max ((hand 0) :CardVal) ((hand 1) :CardVal))]
    [false nil]))

(defn pocketStraightFlush?
  [hand]
  (let [flushData (pocketFlush? hand) straightData (pocketStraight? hand)]
    (if (and (= (flushData 0) true) (= (straightData 0) true))
      [true (flushData 1) (straightData 1)]
      [false nil nil])))

(defn pocketHighHand?
  [hand]
  (if (and (faceCard (hand 0)) (faceCard (hand 1))) [true (max ((hand 0) :CardVal) ((hand 1) :CardVal))] [false nil]))
(ns texas-holdem-ai.brain
  (:use [texas-holdem-ai state card match commonHands pocketHands handState bets util])
  (:gen-class))

;;This file orginates all computation in regards to holdem hands

;;Can i call for free?
(defn canCheck
  [currentState]
  (if (= (getAmountToCall currentState) 0) true false))

(defn checkPreflop
  [currentState]
  (let [pocket (getMyHand currentState) pairs (pocketPairs? pocket) flush (pocketFlush? pocket) straight
    (pocketStraight? pocket) straightflush (pocketStraightFlush? pocket) highHand (pocketHighHand? pocket)]
    (cond
      (pairs 0) (betPreflop "pair" pairs currentState)
      (highHand 0) (betPreflop "highHand" highHand currentState)
      (straightflush 0) (betPreflop "straightflush" straightflush currentState)
      (flush 0) (betPreflop "flush" flush currentState)
      (straight 0) (betPreflop "straight" straight currentState)
      true 0)))

(defn checkFlop
  [currentState]
  (let [pocket (getMyHand currentState) board (getBoard currentState) pairs (pair? pocket board) flush (flush? pocket board) straight
    (straight? pocket board) straightflush (straightflush? pocket board) trips (trips? pocket board) quads (quads? pocket board)
    fullhouse (fullhouse? pocket board) twopair (twopair? pocket board)]
    (cond
      (straightflush 0) (betFlop "straightflush" straightflush currentState)
      (quads 0) (betFlop "quads" quads currentState)
      (fullhouse 0) (betFlop "fullhouse" fullhouse currentState)
      (flush 0) (betFlop "flush" flush currentState)
      (some #{true} straight) (betFlop "straight" straight currentState)
      (trips 0) (betFlop "trips" trips currentState)
      (twopair 0) (betFlop "twopair" twopair currentState)
      (= 4 (flush 1)) (betFlop "4flush" flush currentState)
      (pairs 0) (betFlop "pair" pairs currentState)
      true 0)))

(defn checkTurn
  [currentState]
  (let [pocket (getMyHand currentState) board (getBoard currentState) pairs (pair? pocket board) flush (flush? pocket board) straight
    (straight? pocket board) straightflush (straightflush? pocket board) trips (trips? pocket board) quads (quads? pocket board)
    fullhouse (fullhouse? pocket board) twopair (twopair? pocket board)]
    (cond
      (straightflush 0) (betTurn "straightflush" straightflush currentState)
      (quads 0) (betTurn "quads" quads currentState)
      (fullhouse 0) (betTurn "fullhouse" fullhouse currentState)
      (flush 0) (betTurn "flush" flush currentState)
      (some #{true} straight) (betTurn "straight" straight currentState)
      (trips 0) (betTurn "trips" trips currentState)
      (twopair 0) (betTurn "twopair" twopair currentState)
      (= 4 (flush 1)) (betTurn "4flush" flush currentState)
      (pairs 0) (betTurn "pair" pairs currentState)
      true 0)))

(defn checkRiver
  [currentState]
  (let [pocket (getMyHand currentState) board (getBoard currentState) pairs (pair? pocket board) flush (flush? pocket board) straight
    (straight? pocket board) straightflush (straightflush? pocket board) trips (trips? pocket board) quads (quads? pocket board)
    fullhouse (fullhouse? pocket board) twopair (twopair? pocket board)]
    (cond
      (straightflush 0) (betRiver "straightflush" straightflush currentState)
        (quads 0) (betRiver "quads" quads currentState)
        (fullhouse 0) (betRiver "fullhouse" fullhouse currentState)
        (flush 0) (betRiver "flush" flush currentState)
        (some #{true} straight) (betRiver "straight" straight currentState)
        (trips 0) (betRiver "trips" trips currentState)
        (twopair 0) (betRiver "twopair" twopair currentState)
        (pairs 0) (betRiver "pair" pairs currentState)
        true 0)))

(defn verifyAmount
  [amt currentState]
  (let [raiseAmount (- amt (getAmountToCall currentState))]
    (cond
      (= raiseAmount 0) ["call" "0"]
      (> raiseAmount 0) ["raise" (str raiseAmount)]
      (< raiseAmount 0) ["fold" "0"])))

(defn brain
  [currentState]
  (condp = (getHandState currentState)
    STATE-PREFLOP (verifyAmount (checkPreflop currentState) currentState)
    STATE-FLOP (verifyAmount (checkFlop currentState) currentState)
    STATE-TURN (verifyAmount (checkTurn currentState) currentState)
    STATE-RIVER (verifyAmount (checkRiver currentState) currentState)
    STATE-NONE ["fold" "0"]))
(ns texas-holdem-ai.action
  (:use [texas-holdem-ai brain])
  (:gen-class))

;;This is the file that parses action requests and hands them off to the poker brain

;;Action b t	Request for the bot's next action within given timespan

;All move requests will orginate here.
(defn parseAction
  [type time currentState]
  (let [command (brain currentState)]
    (do
      (println (get command 0) (get command 1))
      currentState)))
(ns texas-holdem-ai.core
  (:use [texas-holdem-ai settings match handState action util])
  (:gen-class))

;;This is the state the game will state with
(def initialState {:gameState 0 :settingsInfo {:init true :your_bot ""} :matchInfo {:init true} :hand [] :board []})


;;This checks the type of the command and hands it off accordingly
(defn checkClass
  [commandList currentState]
  (let [type (get commandList 0) data (get commandList 1) value (get commandList 2)]
    (condp = type
      "Settings" (parseStateSettings data value currentState)
      "Match" (parseStateMatch data value currentState)
      "Action" (parseAction data value currentState)
      "debug" (log currentState) ;;This is just here for debugging purposes, prints out state obj
      (getSetting currentState "your_bot") (parseStateHand type data value currentState)
      currentState))) ;;In the case of bad input, just ignore it entirely

;;Parses line from standard in
(defn parse
  [state line]
  (if (or (empty? line) (= \# (first line)))
    state
    (checkClass (clojure.string/split line #" ") state)))

;;application entry point
(defn -main
  []
  (reduce parse initialState (line-seq (java.io.BufferedReader. *in*))))

(-main) ;This is for running through jars, no lein
